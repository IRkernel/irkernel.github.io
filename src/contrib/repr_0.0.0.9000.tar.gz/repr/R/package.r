#' The repr package
#' 
#' @details
#' The LaTeX repr of vectors needs \code{\\usepackage{paralist}}
#' 
#' @docType package
#' @name repr
NULL